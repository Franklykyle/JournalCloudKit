//
//  Entry.swift
//  JournalCloudKit
//
//  Created by Kyle Franklin on 8/9/21.
//

import Foundation
import CloudKit

struct EntryStrings {
    
    static let recordTypeKey = "Entry"
    fileprivate static let titleKey = "title"
    fileprivate static let bodyKey = "body"
    fileprivate static let timestampKey = "timestamp"
}

class Entry {
    
    let title: String
    let body: String
    let timestamp: Date
    
    let recordID: CKRecord.ID
    
    init(title: String, body: String, timestamp: Date = Date(), recordID: CKRecord.ID = CKRecord.ID(recordName: UUID().uuidString)) {
        self.title = title
        self.body = body
        self.recordID = recordID
        self.timestamp = timestamp
    }
    
}

extension CKRecord {
    
    convenience init(entry: Entry) {
        self.init(recordType: EntryStrings.recordTypeKey, recordID: entry.recordID)
        
        self.setValuesForKeys([
            EntryStrings.titleKey : entry.title,
            EntryStrings.bodyKey: entry.body,
            EntryStrings.timestampKey : entry.timestamp
        ])
    }
}
//let array = [0,1,2]
//array[0]
//let dict = ["one" : "blue", "two" : "green", "three" : "red"]
//dict["two"]
extension Entry {
    
    convenience init?(ckRecord: CKRecord) {
        guard let title = ckRecord[EntryStrings.titleKey] as? String,
              let body = ckRecord[EntryStrings.bodyKey] as? String,
              let timestamp = ckRecord[EntryStrings.timestampKey] as? Date else { return nil }
        
        self.init(title: title, body: body, timestamp: timestamp, recordID: ckRecord.recordID)
        
    }
}
