//
//  EntryController.swift
//  JournalCloudKit
//
//  Created by Kyle Franklin on 8/9/21.
//

import Foundation
import CloudKit

class EntryController {
    
    static let shared = EntryController()
    
    let privateDB = CKContainer.default().privateCloudDatabase
    
    var entries: [Entry] = []
    
    //MARK: - CRUD
    
    func createEntry(title: String, body: String, completion: @escaping (Result<Entry?, EntryError>) -> Void) {
        let newEntry = Entry(title: title, body: body)
        
        let record = CKRecord(entry: newEntry)
        
        privateDB.save(record) { record, error in
            if let error = error {
                return(completion(.failure(.ckError(error))))
            }
            
            guard let record = record,
                  
                  let saveEntry = Entry(ckRecord: record) else { return completion(.failure(.couldNotUnwrap))}
            
            print("Saved Entry")
            completion(.success(saveEntry))
        }

    }
    
    
    func fetchEntries(completion: @escaping (Result<[Entry]?, EntryError>) -> Void) {
        
        let predicate = NSPredicate(value: true)
       
        let query = CKQuery(recordType: EntryStrings.recordTypeKey, predicate: predicate)
        
        privateDB.perform(query, inZoneWith: nil) { records, error in
            
            if let error = error {
                return completion(.failure(.ckError(error)))
            }
            
            guard let records = records else { return completion(.failure(.couldNotUnwrap))}
                
                  print("Records have been fetched")
            
            let entries = records.compactMap({ Entry(ckRecord: $0) })
            completion(.success(entries))
                  
        } // END OF PREFORM
    }
}
