//
//  EntryViewController.swift
//  JournalCloudKit
//
//  Created by Kyle Franklin on 8/9/21.
//

import UIKit

class EntryDetailViewController: UIViewController {
    
    //MARK: - OUTLETS
    @IBOutlet weak var entryTitleTextField: UITextField!
    @IBOutlet weak var entryBodyTextView: UITextView!
    
    //MARK: - PROPERTIES
    
    var entry: Entry?
    
    
    //MARK: - LIFECYCLES
    override func viewDidLoad() {
        super.viewDidLoad()
        updateViews()
    }
    
    //MARK: - ACTION
    @IBAction func saveButtonTapped(_ sender: Any) {
        
        guard let entryTitle = entryTitleTextField.text, !entryTitle.isEmpty else { return }
        guard let entryBody = entryBodyTextView.text, !entryBody.isEmpty else { return }
        
        if let entry = entry {
            print("Update entry: \(entry.title)")
            
            navigationController?.popViewController(animated: true)
        } else {
            EntryController.shared.createEntry(title: entryTitle, body: entryBody) { result in
                DispatchQueue.main.async {
                    switch result {
                    
                    case .success(let entry):
                        guard let entry = entry else { return }
                        EntryController.shared.entries.append(entry)
                        self.navigationController?.popViewController(animated: true)
                    case .failure(let error):
                        print(error)
                    }
                }
            }
        }
        
    }
    
    //MARK: - HELPER METHODS
    func updateViews() {
        
        guard let entry = entry else { return }
        
        entryTitleTextField.text = entry.title
        entryBodyTextView.text = entry.body
        
    }
    
}
