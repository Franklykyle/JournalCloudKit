//
//  EntryError.swift
//  JournalCloudKit
//
//  Created by Kyle Franklin on 8/9/21.
//

import Foundation

enum EntryError: LocalizedError {
    
    case ckError(Error)
    case couldNotUnwrap
    
    var errorDescription: String {
        switch self {
        
        case .ckError(let error):
            return error.localizedDescription
        case .couldNotUnwrap:
            return "Could not get entry"
        }
    }
    
}
