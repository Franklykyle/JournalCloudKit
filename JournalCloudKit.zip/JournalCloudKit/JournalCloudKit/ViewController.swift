//
//  ViewController.swift
//  JournalCloudKit
//
//  Created by Kyle Franklin on 8/9/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

